package com.itheima.mobliesafe75.receiver;

import android.app.admin.DeviceAdminReceiver;

public class Admin extends DeviceAdminReceiver {

}
