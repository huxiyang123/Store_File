package com.example.screenadapter_pic;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_dimen);
		
		float density = getResources().getDisplayMetrics().density;
		Log.d("Test", "设备密度: " + density);
		
		int width = getWindowManager().getDefaultDisplay().getWidth();
		int height = getWindowManager().getDefaultDisplay().getHeight();
		
		TextView tv1 = (TextView) findViewById(R.id.tv1);
		TextView tv2 = (TextView) findViewById(R.id.tv2);
		TextView tv3 = (TextView) findViewById(R.id.tv3);
		
		tv1.setLayoutParams(new LayoutParams((int)(width*0.5), (int)(height*0.2)));
		tv2.setLayoutParams(new LayoutParams((int)(width*0.33), (int)(height*0.2)));
		tv3.setLayoutParams(new LayoutParams((int)(width*0.33), (int)(height*0.2)));
	}

}
