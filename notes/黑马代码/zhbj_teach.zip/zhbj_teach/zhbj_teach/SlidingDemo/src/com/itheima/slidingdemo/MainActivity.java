package com.itheima.slidingdemo;

import android.os.Bundle;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jeremyfeinstein.slidingmenu.lib.app.SlidingFragmentActivity;

public class MainActivity extends SlidingFragmentActivity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		setBehindContentView(R.layout.menu_left);// 设置左侧菜单

		SlidingMenu slidingMenu = getSlidingMenu();// 获取SlidingMenu对象
		slidingMenu.setSecondaryMenu(R.layout.menu_right);// 设置右侧菜单
		slidingMenu.setMode(SlidingMenu.LEFT_RIGHT);// 设置菜单展现模式, 左右两侧都展示

		slidingMenu.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);// 设置触摸方式
		slidingMenu.setBehindOffset(100);// 设置主页面剩余宽度
	}

}
