package com.itcast.googleplayteach.domain;

/**
 * 主题信息封装
 * 
 * @author Kevin
 * 
 */
public class SubjectInfo {

	public String des;
	public String url;

}
