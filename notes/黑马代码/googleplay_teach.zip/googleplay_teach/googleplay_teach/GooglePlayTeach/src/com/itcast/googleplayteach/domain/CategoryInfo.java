package com.itcast.googleplayteach.domain;

public class CategoryInfo {

	public String name1;
	public String name2;
	public String name3;
	public String url1;
	public String url2;
	public String url3;

	public String title;
	public boolean isTitle;// 表示当前对象是否是标题

}
