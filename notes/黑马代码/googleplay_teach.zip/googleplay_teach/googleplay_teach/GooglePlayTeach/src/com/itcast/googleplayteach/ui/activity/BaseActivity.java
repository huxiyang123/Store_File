package com.itcast.googleplayteach.ui.activity;

import android.support.v7.app.ActionBarActivity;

public class BaseActivity extends ActionBarActivity {

}
